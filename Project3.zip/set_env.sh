# This file is used for convenience of local development.
# DO NOT STORE YOUR CREDENTIALS INTO GIT
export POSTGRES_USERNAME=postgres
export POSTGRES_PASSWORD=udacity-cloud-p3
export POSTGRES_HOST=p3-refactor-monolith.coika1oqikvu.us-east-1.rds.amazonaws.com
export POSTGRES_DB=postgres
export AWS_BUCKET=p3-refactor-monolith
export AWS_REGION=us-east-1
export AWS_PROFILE=default
export JWT_SECRET=udacity-p3-refactor-monolith
export URL=http://localhost:8100
